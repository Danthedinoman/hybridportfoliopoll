// Hybrid Portfolio Poll – vanilla JS (no build)
const STORAGE_KEY = 'hybrid-portfolio-poll-v1';
const VOTED_KEY = 'hybrid-portfolio-poll-v1-voted';

const els = {
  form: document.getElementById('pollForm'),
  votedNotice: document.getElementById('votedNotice'),
  kioskBtn: document.getElementById('kioskBtn'),
  shareBtn: document.getElementById('shareBtn'),
  csvBtn: document.getElementById('csvBtn'),
  clearBtn: document.getElementById('clearBtn'),
  allowBtn: document.getElementById('allowBtn'),
  total: document.getElementById('total'),
  avg: document.getElementById('avg'),
  yesRate: document.getElementById('yesRate'),
  topPref: document.getElementById('topPref'),
  rawList: document.getElementById('rawList'),
  chartCanvas: document.getElementById('barChart')
};

let rows = [];
let kiosk = false;
let chart;

// helpers
function loadRows() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch(e) {
    return [];
  }
}
function saveRows() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));
}
function deviceVoted() { return localStorage.getItem(VOTED_KEY) === 'yes'; }
function setDeviceVoted(v) { localStorage.setItem(VOTED_KEY, v ? 'yes' : 'no'); }

function toCSV(rs) {
  const header = ['timestamp','role','age_range','format_preference','likert_usefulness','would_review_both','top_factors','comments'];
  const esc = s => `"${String(s ?? '').replaceAll('"','""')}"`;
  const body = rs.map(r => [
    r.timestamp, r.role, r.ageRange, r.preference, r.usefulness, r.reviewBoth, (r.factors||[]).join(';'), r.comments
  ].map(esc).join(','));
  return header.join(',') + '\n' + body.join('\n') + '\n';
}

function updateUI() {
  els.votedNotice.classList.toggle('hidden', kiosk || !deviceVoted());

  // Stats
  const total = rows.length;
  els.total.textContent = total;

  const prefCounts = {physical:0,digital:0,hybrid:0};
  let usefulSum = 0, yes = 0;
  rows.forEach(r => {
    prefCounts[r.preference] = (prefCounts[r.preference] || 0) + 1;
    usefulSum += Number(r.usefulness||0);
    if ((r.reviewBoth||'').toLowerCase()==='yes') yes++;
  });
  els.avg.textContent = total ? (usefulSum/total).toFixed(2) : '0';
  els.yesRate.textContent = total ? Math.round((100*yes)/total) + '%' : '0%';
  const top = Object.entries(prefCounts).sort((a,b)=>b[1]-a[1])[0];
  els.topPref.textContent = top && top[1] ? top[0] : '—';

  // Chart
  const data = [prefCounts.physical, prefCounts.digital, prefCounts.hybrid];
  if (!chart) {
    chart = new Chart(els.chartCanvas, {
      type: 'bar',
      data: {
        labels: ['Physical','Digital','Hybrid'],
        datasets: [{ label: 'Votes', data }]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: true, precision:0 } }
      }
    });
  } else {
    chart.data.datasets[0].data = data;
    chart.update();
  }

  // Raw list
  els.rawList.innerHTML = rows.map(r => `
    <div class="rawItem">
      <div class="ts">${r.timestamp}</div>
      <div><b>Role:</b> ${r.role} • <b>Age:</b> ${r.ageRange}</div>
      <div><b>Preference:</b> ${r.preference} • <b>Usefulness:</b> ${r.usefulness} • <b>Review both:</b> ${r.reviewBoth}</div>
      ${r.factors?.length ? `<div><b>Factors:</b> ${r.factors.join(', ')}</div>` : ''}
      ${r.comments ? `<div class="it">“${r.comments}”</div>` : ''}
    </div>
  `).join('') || '<div class="muted">No responses yet.</div>';
}

// init
rows = loadRows();
updateUI();

// form submit
els.form.addEventListener('submit', (e) => {
  e.preventDefault();
  if (!kiosk && deviceVoted()) return;

  const fd = new FormData(els.form);
  const entry = {
    timestamp: new Date().toISOString(),
    role: fd.get('role'),
    ageRange: fd.get('age'),
    preference: fd.get('pref'),
    usefulness: fd.get('usefulness'),
    reviewBoth: fd.get('both'),
    factors: fd.getAll('factors'),
    comments: fd.get('comments')?.trim() || ''
  };
  rows = [entry, ...rows];
  saveRows();
  if (!kiosk) setDeviceVoted(true);
  els.form.reset();
  // set some defaults back
  els.form.querySelector('input[name="role"][value="student"]').checked = true;
  els.form.querySelector('input[name="age"][value="<18"]').checked = true;
  els.form.querySelector('input[name="pref"][value="hybrid"]').checked = true;
  els.form.querySelector('input[name="usefulness"][value="3"]').checked = true;
  els.form.querySelector('input[name="both"][value="yes"]').checked = true;
  els.form.querySelector('input[name="factors"][value="easy"]').checked = true;
  els.form.querySelector('input[name="factors"][value="detail"]').checked = true;

  updateUI();
});

// kiosk toggle
els.kioskBtn.addEventListener('click', () => {
  kiosk = !kiosk;
  els.kioskBtn.textContent = kiosk ? 'Kiosk Mode: ON' : 'Kiosk Mode: OFF';
  updateUI();
});

// share
els.shareBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(window.location.href);
    alert('Link copied to clipboard!');
  } catch (e) { alert('Copy failed. You can copy the URL from the address bar.'); }
});

// download CSV
els.csvBtn.addEventListener('click', () => {
  const csv = toCSV(rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `hybrid-portfolio-poll-${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

// clear + allow re-vote
els.clearBtn.addEventListener('click', () => {
  if (confirm('Clear all saved responses on this device?')) {
    localStorage.removeItem(STORAGE_KEY);
    rows = [];
    if (!kiosk) { localStorage.removeItem(VOTED_KEY); }
    updateUI();
  }
});
els.allowBtn.addEventListener('click', () => {
  localStorage.removeItem(VOTED_KEY);
  updateUI();
});
